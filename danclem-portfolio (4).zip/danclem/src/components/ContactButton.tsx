import type { ReactNode } from 'react'
import { SITE } from '../data/site'
type Props = { children?: ReactNode; href?: string; className?: string; onClick?: () => void; disabled?: boolean; external?: boolean }
export function GradientButton({ children, href, className = '', onClick, disabled, external }: Props) {
  const cls = `btn-grad inline-flex items-center justify-center rounded-full font-medium ${disabled ? 'opacity-50 pointer-events-none' : ''} ${className}`
  if (href && !disabled) return <a href={href} className={cls} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>{children}</a>
  return <button type="button" className={cls} onClick={onClick} disabled={disabled}>{children}</button>
}
export default function ContactButton({ className = '', label = "Let’s talk!" }: { className?: string; label?: string }) {
  return <GradientButton href={SITE.whatsapp} external className={className}>{label}</GradientButton>
}
