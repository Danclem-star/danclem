import { SITE } from '../data/site'
import { InstagramIcon, LinkedinIcon, XIcon, YoutubeIcon } from './Icons'
export default function SocialLinks() {
  const items = [
    { href: SITE.x, label: 'X', Icon: XIcon }, { href: SITE.instagram, label: 'Instagram', Icon: InstagramIcon },
    { href: SITE.linkedin, label: 'LinkedIn', Icon: LinkedinIcon }, { href: SITE.youtube, label: 'YouTube', Icon: YoutubeIcon },
  ].filter(i => i.href)
  return (
    <ul className="flex gap-2">
      {items.map(({ href, label, Icon }) => (
        <li key={label}><a href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
          className="flex h-9 w-9 items-center justify-center rounded-md border border-white/40 text-white/80 transition hover:bg-white/15 hover:text-white"><Icon /></a></li>
      ))}
    </ul>
  )
}
