import { useState } from 'react'
import { GradientButton } from '../components/ContactButton'
import { SITE } from '../data/site'
export default function Resume() {
  const [msg, setMsg] = useState('')
  const open = async () => {
    try {
      const r = await fetch(SITE.resume, { method: 'HEAD' })
      if (r.ok && (r.headers.get('content-type') || '').includes('pdf')) { window.open(SITE.resume, '_blank', 'noopener'); return }
    } catch { /* fall through */ }
    setMsg('Resume not added yet. Place your file at public/resume.pdf.')
  }
  return (
    <div className="gutter mx-auto min-h-[56vh] max-w-[1800px] pt-16 lg:min-h-[920px] lg:pt-36">
      <h1 className="text-[clamp(2rem,3.2vw,3.25rem)] font-bold uppercase leading-none">Resume</h1>
      <p className="mt-4 text-[clamp(1rem,1.35vw,1.3rem)] text-neutral-600">A concise view of my product design practice and selected work.</p>
      <GradientButton onClick={open} className="mt-10 h-16 w-full text-lg sm:w-[min(25vw,431px)] sm:min-w-[300px] lg:h-[75px] lg:text-xl">Download resume</GradientButton>
      <p role="status" className="mt-4 text-sm text-neutral-600">{msg}</p>
    </div>
  )
}
