import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import ContactButton from './ContactButton'
const links = [{ to: '/work', label: 'Work' }, { to: '/about', label: 'About' }, { to: '/resume', label: 'Resume' }]
export default function Navbar() {
  const [open, setOpen] = useState(false)
  const cls = ({ isActive }: { isActive: boolean }) => `rounded-full px-4 py-2 text-[15px] transition-colors hover:bg-neutral-100 lg:px-[22px] lg:text-[clamp(1rem,1.5vw,1.65rem)] ${isActive ? 'font-medium' : ''}`
  return (
    <header className="gutter relative z-20 pt-5 lg:pt-10">
      <div className="flex items-center justify-between">
        <Link to="/" className="font-hand text-3xl leading-none lg:text-4xl" aria-label="Danclem home">Danclem</Link>
        <nav aria-label="Primary" className="hidden items-center rounded-full bg-white px-3 sm:flex lg:h-[75px] lg:px-4">
          {links.map(l => <NavLink key={l.to} to={l.to} className={cls}>{l.label}</NavLink>)}
        </nav>
        <div className="flex items-center gap-2">
          <ContactButton className="px-5 py-2.5 text-sm sm:px-7 sm:py-3 lg:h-[75px] lg:px-12 lg:py-0 lg:text-[clamp(1.1rem,1.65vw,1.7rem)]" />
          <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white sm:hidden" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(o => !o)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </div>
      {open && <nav aria-label="Mobile" className="mt-3 flex flex-col rounded-2xl bg-white p-2 sm:hidden">
        {links.map(l => <NavLink key={l.to} to={l.to} onClick={() => setOpen(false)} className={cls}>{l.label}</NavLink>)}
      </nav>}
    </header>
  )
}
