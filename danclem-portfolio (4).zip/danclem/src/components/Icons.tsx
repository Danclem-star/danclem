const p = { width: 18, height: 18, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true } as const
export const XIcon = () => <svg {...p}><path d="M4 4l16 16M20 4L4 20" /></svg>
export const InstagramIcon = () => <svg {...p}><rect x="4" y="4" width="16" height="16" rx="5" /><circle cx="12" cy="12" r="3.6" /><circle cx="16.8" cy="7.2" r=".6" fill="currentColor" /></svg>
export const LinkedinIcon = () => <svg {...p}><path d="M7 10v7M7 7v.01M11 17v-7M11 13a3 3 0 016 0v4" /></svg>
export const YoutubeIcon = () => <svg {...p}><rect x="3" y="6" width="18" height="12" rx="4" /><path d="M10.5 9.5v5l4-2.5z" /></svg>
