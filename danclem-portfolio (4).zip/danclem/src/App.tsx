import { useEffect } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import { motion, useReducedMotion } from 'framer-motion'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Work from './pages/Work'
import About from './pages/About'
import Resume from './pages/Resume'
import Contact from './pages/Contact'
export default function App() {
  const { pathname } = useLocation()
  const reduce = useReducedMotion()
  useEffect(() => window.scrollTo(0, 0), [pathname])
  return (
    <>
      <Navbar />
      <motion.main key={pathname} initial={reduce ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <Routes>
          <Route path="/" element={<Home />} /><Route path="/work" element={<Work />} /><Route path="/about" element={<About />} />
          <Route path="/resume" element={<Resume />} /><Route path="/contact" element={<Contact />} /><Route path="*" element={<Home />} />
        </Routes>
      </motion.main>
      <Footer />
    </>
  )
}
