const groups = [
  { h: 'Experience', items: ['Product Design', 'UI/UX Design', 'User Research', 'Design Systems', 'Prototyping', 'Developer Collaboration'], list: true },
  { h: 'Tools', items: ['Figma', 'Framer', 'Adobe Illustrator', 'Photoshop', 'Canva'] },
  { h: 'Industries', items: ['Fintech', 'E-commerce', 'Marketplace', 'Consumer Products', 'EdTech'] },
]
export default function About() {
  return (
    <div className="mx-auto max-w-[1440px] px-5 pb-8 pt-14 sm:px-6 lg:px-[26px] lg:pt-20">
      <div className="grid items-start gap-10 md:grid-cols-[1fr_auto]">
        <div className="max-w-[820px]">
          <h1 className="text-[clamp(1.9rem,3.6vw,2.9rem)] font-semibold leading-[1.15]">Designer focused on making complex products feel simple.</h1>
          <p className="mt-5 max-w-[760px] text-base leading-snug text-neutral-600 sm:text-lg">I’m Toluwalase Daniel, a product designer who enjoys making ambitious ideas easier to understand and use. I work across web and mobile, partnering with thoughtful teams on products where clarity can unlock momentum.</p>
        </div>
        <img src="/images/profile.jpg" alt="Portrait of Toluwalase Daniel" className="h-52 w-52 rounded-full object-cover object-top md:mr-[6vw] md:h-[300px] md:w-[300px] lg:h-[340px] lg:w-[340px]" />
      </div>
      <div className="mt-16 space-y-8 sm:pl-6">
        {groups.map(g => (
          <section key={g.h}>
            <h2 className="text-2xl font-medium">{g.h}</h2>
            {g.list ? <ul className="mt-1 text-neutral-600 sm:text-lg">{g.items.map(i => <li key={i}>{i}</li>)}</ul>
              : <p className="mt-1 text-neutral-600 sm:text-lg">{g.items.join(' · ')}</p>}
          </section>
        ))}
      </div>
    </div>
  )
}
