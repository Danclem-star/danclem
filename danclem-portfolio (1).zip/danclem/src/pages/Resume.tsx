import { useState } from 'react'
import { GradientButton } from '../components/ContactButton'
import { SITE } from '../data/site'
export default function Resume() {
  const [msg, setMsg] = useState('')
  const open = async () => {
    try {
      const r = await fetch(SITE.resume, { method: 'HEAD' })
      if (r.ok && (r.headers.get('content-type') || '').includes('pdf')) { window.open(SITE.resume, '_blank', 'noopener'); return }
    } catch { /* fall through */ }
    setMsg('Resume not added yet. Place your file at public/resume.pdf.')
  }
  return (
    <div className="mx-auto min-h-[56vh] max-w-[1440px] px-5 pt-16 sm:px-6 lg:px-[26px] lg:pt-20">
      <h1 className="text-4xl font-semibold uppercase">Resume</h1>
      <p className="mt-3 text-neutral-600 sm:text-lg">A concise view of my product design practice and selected work.</p>
      <GradientButton onClick={open} className="mt-8 w-full px-16 py-5 text-lg sm:w-auto">Download resume</GradientButton>
      <p role="status" className="mt-4 text-sm text-neutral-600">{msg}</p>
    </div>
  )
}
