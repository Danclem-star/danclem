import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import ContactButton from './ContactButton'
const links = [{ to: '/work', label: 'Work' }, { to: '/about', label: 'About' }, { to: '/resume', label: 'Resume' }]
export default function Navbar() {
  const [open, setOpen] = useState(false)
  const cls = ({ isActive }: { isActive: boolean }) => `rounded-full px-4 py-2 text-[15px] transition-colors hover:bg-neutral-100 ${isActive ? 'font-medium' : ''}`
  return (
    <header className="relative z-20 px-5 pt-5 sm:px-6 lg:px-[26px]">
      <div className="relative flex items-center justify-between">
        <Link to="/" className="font-hand text-3xl leading-none" aria-label="Danclem home">Danclem</Link>
        <nav aria-label="Primary" className="absolute left-1/2 hidden -translate-x-1/2 rounded-full bg-white px-3 py-2.5 sm:flex">
          {links.map(l => <NavLink key={l.to} to={l.to} className={cls}>{l.label}</NavLink>)}
        </nav>
        <div className="flex items-center gap-2">
          <ContactButton className="px-5 py-2.5 text-sm sm:px-7 sm:py-3" />
          <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white sm:hidden" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(o => !o)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </div>
      {open && <nav aria-label="Mobile" className="mt-3 flex flex-col rounded-2xl bg-white p-2 sm:hidden">
        {links.map(l => <NavLink key={l.to} to={l.to} onClick={() => setOpen(false)} className={cls}>{l.label}</NavLink>)}
      </nav>}
    </header>
  )
}
