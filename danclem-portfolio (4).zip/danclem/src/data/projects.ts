export type Project = { n: string; title: string; desc: string; tags: string; image: string }
export const projects: Project[] = [
  { n: '01', title: 'LETI', desc: 'Designing a multi-sided marketplace connecting property owners, service providers and customers.', tags: 'Marketplace · Mobile · Web', image: '/images/leti-cover.png' },
  { n: '02', title: 'SUPERGLOWW', desc: 'Designing a modern skincare shopping experience focused on discovery, trust and conversion.', tags: 'E-commerce · Web · Conversion', image: '/images/supergloww-cover.png' },
  { n: '03', title: 'LUMI AI', desc: 'Designing an AI-powered energy estimation experience that helps users understand, forecast and manage energy usage.', tags: 'SaaS · Mobile · Web', image: '/images/lumi-ai-cover.png' },
  { n: '04', title: 'BLIBBS', desc: 'Simplifying and bridging the gap between digital currencies and everyday shopping.', tags: 'E-commerce · Web', image: '/images/blibbs-cover.png' },
]
