const groups = [
  { h: 'Experience', items: ['Product Design', 'UI/UX Design', 'User Research', 'Design Systems', 'Prototyping', 'Developer Collaboration'], list: true },
  { h: 'Tools', items: ['Figma', 'Framer', 'Adobe Illustrator', 'Photoshop', 'Canva'] },
  { h: 'Industries', items: ['Fintech', 'E-commerce', 'Marketplace', 'Consumer Products', 'EdTech'] },
]
export default function About() {
  return (
    <div className="gutter mx-auto max-w-[1800px] pb-8 pt-12 lg:pt-36">
      <div className="grid items-start gap-10 md:grid-cols-[1fr_auto]">
        <div>
          <h1 className="max-w-[40vw] text-[clamp(1.9rem,2.8vw,2.9rem)] font-semibold leading-[1.2] max-md:max-w-none">Designer focused on making complex products feel simple.</h1>
          <p className="mt-5 max-w-[50vw] text-[clamp(1rem,1.4vw,1.35rem)] leading-[1.45] text-neutral-600 max-md:max-w-none">I’m Toluwalase Daniel, a product designer who enjoys making ambitious ideas easier to understand and use. I work across web and mobile, partnering with thoughtful teams on products where clarity can unlock momentum.</p>
        </div>
        <div className="h-56 w-56 overflow-hidden rounded-full sm:h-64 sm:w-64 md:mr-[6.6vw] md:-mt-6 md:h-[21vw] md:w-[21vw] md:min-h-[240px] md:min-w-[240px]"><img src="/images/profile.jpg" alt="Portrait of Toluwalase Daniel" className="h-full w-full scale-[1.25] object-cover [transform-origin:50%_40%]" /></div>
      </div>
      <div className="mt-14 space-y-9 sm:pl-5 lg:mt-[4vw]">
        {groups.map(g => (
          <section key={g.h}>
            <h2 className="text-[clamp(1.5rem,2.1vw,2.1rem)] font-medium leading-tight">{g.h}</h2>
            <ul className={`mt-1 text-[clamp(1rem,1.35vw,1.3rem)] leading-[1.4] text-neutral-600 ${g.list ? '' : 'flex flex-wrap'}`}>
              {g.items.map((i, k) => <li key={i} className="flex">{i}{!g.list && k < g.items.length - 1 && <span aria-hidden className="px-1">·</span>}</li>)}
            </ul>
          </section>
        ))}
      </div>
    </div>
  )
}
