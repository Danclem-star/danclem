import { GradientButton } from '../components/ContactButton'
import { SITE } from '../data/site'
export default function Contact() {
  const links = [{ l: 'LinkedIn', h: SITE.linkedin }, { l: 'X (Twitter)', h: SITE.x }, { l: 'Instagram', h: SITE.instagram }].filter(i => i.h)
  return (
    <div className="mx-auto min-h-[56vh] max-w-[1440px] gutter pt-16 lg:pt-36">
      <h1 className="text-3xl font-semibold sm:text-4xl">Let’s build something useful.</h1>
      <p className="mt-3 sm:text-lg">I’m open to product design opportunities, freelance projects and collaborations.</p>
      <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-center sm:gap-10">
        <GradientButton href={SITE.email ? `mailto:${SITE.email}` : undefined} disabled={!SITE.email} className="px-16 py-5 text-lg">Send a mail</GradientButton>
        <ul className="flex flex-wrap gap-x-8 gap-y-2 sm:text-lg">
          {links.map(i => <li key={i.l}><a className="underline underline-offset-4" href={i.h} target="_blank" rel="noopener noreferrer">{i.l}</a></li>)}
        </ul>
      </div>
    </div>
  )
}
