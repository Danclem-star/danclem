export default function SectionHeading({ title = 'Selected works' }: { title?: string }) {
  return (
    <div className="mx-auto max-w-[560px] px-6 text-center">
      <h2 className="text-xl font-medium sm:text-2xl">{title}</h2>
      <p className="mt-2 text-sm leading-snug text-neutral-600 sm:text-base">A selection of products and interfaces I’ve designed across Fintech, Lifestyle, E-commerce, marketplace and consumer products</p>
    </div>
  )
}
