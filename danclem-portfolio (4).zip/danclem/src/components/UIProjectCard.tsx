import type { UIDesign } from '../data/uiDesigns'
import Reveal from './Reveal'
export default function UIProjectCard({ d }: { d: UIDesign }) {
  return (
    <Reveal className="px-5 sm:px-6 lg:px-[26px]">
      <h3 className="text-xl font-medium sm:text-2xl">{d.title}</h3>
      <p className="mt-1.5 flex items-center gap-2 text-xs text-neutral-600"><img src="/images/profile.jpg" alt="" className="h-4 w-4 rounded-full object-cover" />Danclem</p>
      <img src={d.image} alt={d.alt} loading="lazy" className={`mx-auto mt-8 block w-full ${d.width}`} />
    </Reveal>
  )
}
