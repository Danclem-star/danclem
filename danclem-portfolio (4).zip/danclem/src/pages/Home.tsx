import SectionHeading from '../components/SectionHeading'
import ProjectCard from '../components/ProjectCard'
import ContactButton from '../components/ContactButton'
import { projects } from '../data/projects'
export default function Home() {
  return (
    <>
      <section className="mx-auto grid max-w-[1440px] items-center gap-8 px-5 pb-16 pt-14 sm:px-6 md:grid-cols-[1fr_auto] lg:px-[26px] lg:pt-16">
        <div className="max-w-[640px]">
          <p className="text-[11px] uppercase text-neutral-600">Product designer, UI/UX, Web &amp; Mobile</p>
          <h1 className="mt-1 text-[clamp(1.75rem,3.4vw,2.6rem)] font-semibold leading-[1.15]">Designing digital products that are simple to use and hard to ignore.</h1>
          <p className="mt-4 max-w-[460px] text-sm text-neutral-600">I’m Toluwalase Daniel, a product designer focused on turning complex ideas into clear, useful and engaging digital experiences.</p>
          <ContactButton className="mt-5 px-12 py-3.5 text-sm" />
        </div>
        <img src="/images/profile.jpg" alt="Portrait of Toluwalase Daniel" className="h-44 w-44 rounded-full object-cover object-top sm:h-52 sm:w-52 md:mr-[8vw] md:h-[190px] md:w-[190px]" />
      </section>
      <section className="pt-10"><SectionHeading />
        <div className="mx-auto mt-20 max-w-[1440px]">{projects.map(p => <ProjectCard key={p.n} p={p} />)}</div>
      </section>
    </>
  )
}
