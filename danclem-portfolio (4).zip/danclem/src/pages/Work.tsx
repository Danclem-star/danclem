import { useState } from 'react'
import SectionHeading from '../components/SectionHeading'
import ProjectCard from '../components/ProjectCard'
import UIProjectCard from '../components/UIProjectCard'
import { GradientButton } from '../components/ContactButton'
import { projects } from '../data/projects'
import { uiDesigns } from '../data/uiDesigns'
import { SITE } from '../data/site'
const tabs = ['Case studies', 'UI designs'] as const
export default function Work() {
  const [tab, setTab] = useState<(typeof tabs)[number]>('Case studies')
  return (
    <section className="pt-14 sm:pt-16">
      <SectionHeading />
      <div role="tablist" className="mx-5 mb-16 mt-14 flex gap-2 sm:mx-6 lg:mx-[26px]">
        {tabs.map(t => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`rounded-xl px-6 py-4 text-sm font-medium transition-colors duration-200 sm:px-9 ${tab === t ? 'bg-[#1a1a1a] text-white' : 'text-neutral-800 hover:bg-white/70'}`}>{t}</button>
        ))}
      </div>
      <div className="mx-auto max-w-[1440px]">
        {tab === 'Case studies' ? projects.map(p => <ProjectCard key={p.n} p={p} />) : (
          <div className="space-y-20 sm:space-y-28">
            {uiDesigns.map(d => <UIProjectCard key={d.title} d={d} />)}
            <div className="flex justify-center px-5"><GradientButton href={SITE.behance || undefined} className="px-12 py-4 text-sm" disabled={!SITE.behance}>Click to view more design</GradientButton></div>
          </div>
        )}
      </div>
    </section>
  )
}
