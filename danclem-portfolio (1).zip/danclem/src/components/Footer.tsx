import ContactButton from './ContactButton'
import SocialLinks from './SocialLinks'
export default function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden text-white" style={{ background: "url(/images/footer-bg.jpg) center/cover, linear-gradient(180deg,#3d4a63 0%,#1c2230 55%,#0b0d10 100%)" }}>
      <div className="absolute inset-0 bg-black/30" />
      <div className="relative mx-auto grid max-w-[1440px] gap-12 px-6 py-14 lg:grid-cols-[1fr_2fr_1fr] lg:items-start lg:px-[34px] lg:py-20">
        <div className="max-w-[300px]">
          <p className="text-2xl font-semibold tracking-tight">DANCLEM UI UX</p>
          <p className="mt-3 text-sm leading-snug text-white/70">I’m not just here to design products; I’m here to connect with people building meaningful products.</p>
          <div className="mt-3"><SocialLinks /></div>
        </div>
        <div className="text-center">
          <p className="text-sm uppercase text-white/70">Available for work</p>
          <h2 className="mx-auto mt-2 max-w-[640px] text-4xl font-medium leading-[1.15] sm:text-5xl">Let’s create something great together.</h2>
          <ContactButton className="mt-6 px-14 py-4 text-base" />
        </div>
        <div className="hidden lg:block" />
      </div>
    </footer>
  )
}
