export type UIDesign = { title: string; image: string; alt: string; width: string }
export const uiDesigns: UIDesign[] = [
  { title: 'UI design for fintech app - Novabanq', image: '/images/novabanq.png', alt: 'Novabanq fintech app screens', width: 'max-w-[420px]' },
  { title: 'UI design for fintech app - Flexxpay', image: '/images/flexxpay.png', alt: 'Flexxpay fintech app screens', width: 'max-w-[560px]' },
  { title: 'Hero section design - Alternate', image: '/images/alternate.png', alt: 'Alternate hero section design', width: 'max-w-[720px]' },
  { title: 'Hero section design - Interchange', image: '/images/interchange.png', alt: 'Interchange hero section design', width: 'max-w-[720px]' },
]
