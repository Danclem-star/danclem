import { motion, useReducedMotion } from 'framer-motion'
import type { Project } from '../data/projects'
import { GradientButton } from './ContactButton'
import Reveal from './Reveal'
export default function ProjectCard({ p }: { p: Project }) {
  const reduce = useReducedMotion()
  return (
    <Reveal>
      <article className="border-t border-neutral-300 px-5 pt-5 sm:px-6 lg:px-[26px]">
        <div className="grid grid-cols-[2rem_1fr] gap-x-3 sm:grid-cols-[2.6rem_1fr_auto] sm:gap-x-6">
          <span className="pt-1 text-xs">{p.n}</span>
          <div>
            <h3 className="text-2xl font-medium leading-tight">{p.title}</h3>
            <p className="mt-1 max-w-[290px] text-[13px] leading-snug text-neutral-600">{p.desc}</p>
            <p className="mt-1.5 text-[13px]">{p.tags}</p>
          </div>
          <div className="col-span-2 mt-4 sm:col-span-1 sm:mt-0"><GradientButton className="px-6 py-3 text-sm">View case study</GradientButton></div>
        </div>
        <div className="mb-14 mt-6 overflow-hidden rounded-sm sm:mb-24 sm:ml-[3.6rem] sm:mt-8">
          <motion.img src={p.image} alt={`${p.title} cover`} loading="lazy" className="block w-full" whileHover={reduce ? undefined : { scale: 1.015 }} transition={{ duration: 0.4 }} />
        </div>
      </article>
    </Reveal>
  )
}
