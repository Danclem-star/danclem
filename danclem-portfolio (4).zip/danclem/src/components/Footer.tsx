import ContactButton from './ContactButton'
import SocialLinks from './SocialLinks'
export default function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden text-white" style={{ background: "url(/images/footer-bg.jpg) center/cover, linear-gradient(180deg,#3d4a63 0%,#1c2230 55%,#0b0d10 100%)" }}>
      <div className="absolute inset-0 bg-black/30" />
      <div className="relative grid gap-12 px-6 py-14 lg:grid-cols-[22vw_1fr] lg:items-start lg:gap-0 lg:pb-[13.5vw] lg:pl-[5.1vw] lg:pr-[8.1vw] lg:pt-[9vw]">
        <div className="max-w-[340px] lg:max-w-none">
          <p className="text-2xl font-semibold tracking-tight lg:text-[2.1vw]">DANCLEM UI UX</p>
          <p className="mt-3 text-sm leading-snug text-white/70 lg:max-w-[23vw] lg:text-[1.15vw]">I’m not just here to design products; I’m here to connect with people building meaningful products.</p>
          <div className="mt-3"><SocialLinks /></div>
        </div>
        <div className="text-center">
          <p className="text-sm uppercase text-white/70 lg:text-[1.15vw]">Available for work</p>
          <h2 className="mx-auto mt-2 max-w-[640px] text-4xl font-medium leading-[1.15] sm:text-5xl lg:max-w-[46vw] lg:text-[4.2vw]">Let’s create something great together.</h2>
          <ContactButton className="mt-6 px-14 py-4 text-base lg:mt-[2.2vw] lg:h-[75px] lg:w-[23vw] lg:py-0 lg:text-[clamp(1.1rem,1.65vw,1.7rem)]" />
        </div>
      </div>
    </footer>
  )
}
