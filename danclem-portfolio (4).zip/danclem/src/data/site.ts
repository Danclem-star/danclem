// Fill in the empty values to enable the matching links. Empty values are hidden / disabled, never faked.
export const SITE = {
  whatsapp: 'https://wa.me/2349037597907', // 09037597907 → +234 9037597907
  email: '',      // e.g. 'you@example.com' → enables "Send a mail"
  linkedin: '',   // full LinkedIn profile URL
  x: 'https://x.com/DanclemUIUX',
  instagram: 'https://instagram.com/danclemuiux',
  youtube: '',    // optional
  behance: 'https://www.behance.net/toluwalasedaniel',    // link for "Click to view more design"
  resume: '/resume.pdf', // drop your file at public/resume.pdf
}
